import { Component, OnInit } from '@angular/core';
import { IonicModule, AlertController } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ConsumoAPIService } from '../services/consumo-api.service';

@Component({
  selector: 'app-registrar-asistencia',
  templateUrl: './registrar-asistencia.page.html',
  styleUrls: ['./registrar-asistencia.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule]
})
export class RegistrarAsistenciaPage implements OnInit {
  alumnoId: number = 0;
  codigo: string = '';
  seccion: string = '';

  constructor(
    private router: Router,
    private consumoAPI: ConsumoAPIService,
    private alertController: AlertController  // <--- inyectar AlertController
  ) {
    const navData = this.router.getCurrentNavigation()?.extras.state;
    if (navData) {
      this.alumnoId = navData['alumnoId'] || 0;
      this.codigo   = navData['codigo']   || '';
      this.seccion = navData['seccion']  || '';
    }
  }

  ngOnInit() {}

  async simularEscaneo() {
    // Chequea en consola que entre aquí
    console.log('Presionó "Simular Escaneo"');

    const fecha = new Date().toISOString().split('T')[0];
    this.consumoAPI.registrarAsistencia(this.alumnoId, this.codigo, this.seccion, fecha)
      .subscribe({
        next: async (resp) => {
          console.log('Asistencia registrada', resp);

          // Muestra un AlertController de éxito
          const alert = await this.alertController.create({
            header: 'Asistencia',
            message: '¡Asistencia registrada con éxito!',
            buttons: ['OK']
          });
          await alert.present();
        },
        error: async (err) => {
          console.error('Error registrando asistencia', err);

          // Muestra un Alert de error
          const alert = await this.alertController.create({
            header: 'Error',
            message: 'Hubo un problema al registrar la asistencia',
            buttons: ['OK']
          });
          await alert.present();
        }
      });
  }

  volverACursos() {
    this.router.navigate(['/curso-lista-alumno']);
  }
}
