import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-404',
  templateUrl: './404.page.html',
  styleUrls: ['./404.page.scss'],
})
export class 404Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
